<?php
$page_title = "Add Manufacturer";
include_once "header.php";
?>
  <div class="inventory-list">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="inventory-table">
            <h3>Add Manufcturer</h3>
            
            <form method="post" id="myForm">
              <div class="form-group">
                <label>Manufcturer Name:</label>
                <input type="text" class="form-control" name="manufacturer_name" id="manufacturer_name" placeholder="Please Enter Manufcturer Name">
              </div>

              <button type="submit" id="submit" class="btn btn-primary">Submit</button>
            </form>
            
           </div>
        </div>
    </div>
    </div>
    </div>
  
<?php
include_once "footer.php";
?>