<?php 
include_once 'classes/database.php'; 
include_once 'classes/manufacturer.php'; 
$manufacturer = new Manufacturer($db);     
$manufacturer->addManufacturerToDb();
?>