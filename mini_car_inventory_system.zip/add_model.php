
<?php 
include_once 'classes/database.php'; 
include_once 'classes/manufacturer.php'; 
$manufacturer = new Manufacturer($db); 
$drop_data = $manufacturer->getManufacturers();
$page_title = "Add Model";
include_once "header.php";
?>

  <div class="inventory-list">
    <div class="container">
      <div class="row">
        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
        <div class="inventory-table">
            <h3>Add Model</h3>
            
            <form method="post" id="myForm1" class="form-inline">
              <div class="form-group">
                <label>Manufcturer Name:</label>
              
         <select class="form-control" name="manufacturer_name" id="manufacturer_name">
             <option value="0">--- Select Manufacturer Name ---</option>
             <?php  while($row = $drop_data->fetch_assoc()){ ?>

        <option value="<?php echo $row['manufacturer_id']; ?>"> <?php echo $row['manufacturer_name']; ?> </option>
                <?php  } ?>
       </select>
                  
                  
                  
              </div>
                <div class="form-group">
                <label>Model Name:</label>
                <input type="text" class="form-control" name="model_name" id="model_name" placeholder="Please Enter Model Name">
              </div>
              
  <div class="form-group">
              <button type="submit" id="submit1" class="btn btn-primary">Submit</button>
       </div>
            </form>
            
           </div>
        </div>
    </div>
    </div>
    </div>
  
<?php
include_once "footer.php";
?>