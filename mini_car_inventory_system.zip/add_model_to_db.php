<?php 
include_once 'classes/database.php'; 
include_once 'classes/model.php'; 
$model = new Model($db);     
$model->addModelToDb();
?>