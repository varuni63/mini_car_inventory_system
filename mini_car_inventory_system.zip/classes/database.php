<?php
class Database{
    private $hostname = 'localhost';
    private $username = 'root';
    private $password = '';
    private $db_name = 'car_inventory';
    public $db_conn;
    
    public function getDbConnection(){
       $this->db_conn = null;

       $this->db_conn = new mysqli($this->hostname, $this->username, $this->password, $this->db_name);
        
        if ($this->db_conn->connect_error) {
            die("Connection failed: " . $this->db_conn->connect_error);
        } 
        else{
           return $this->db_conn;
        }
     }
}
$database = new Database();
$db = $database->getDbConnection();
?>