<?php
class Manufacturer{
    public $db_conn;
    public $table_name = "manufacturer";
    public $manufacturer_name;
    public $manufacturer_id;
    
    public function __construct($db){
        $this->db_conn = $db;
    }
    public function addManufacturerToDb(){
       if(isset($_POST['manufacturer_name'])){
           echo $sql = "INSERT INTO $this->table_name (`manufacturer_name`) VALUES ('".$_POST['manufacturer_name']."')";
           
            if ($this->db_conn->query($sql) === TRUE) {
              return true;
            } 
       }
       }
    public function getManufacturers(){
        $sql = "SELECT * FROM $this->table_name";
        $result = $this->db_conn->query($sql);
        return $result;

    }
    
//    public function getManufacturersById(){
//       
//       echo $sql = "SELECT `manufacturer_name` FROM $this->table_name WHERE `manufacturer_id` = '".$this->manufacturer_id."'";
//        $result = $this->db_conn->query($sql);
//        while($row1 = $result->fetch_assoc()){ 
//            
//            $this->manufacturer_name = $row['manufacturer_name'];
//            return $this->manufacturer_name;
//        }
//    }
    
}

?>