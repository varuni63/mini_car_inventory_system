<?php
class Model{
    public $db_conn;
    public $table_name = "model";
//    public $model_name;
//    public $model_id;
    
    public function __construct($db){
        $this->db_conn = $db;
    }
    public function addModelToDb(){
        var_dump($_POST['manufacturer_name']);
       if(isset($_POST['manufacturer_name']) && isset($_POST['model_name'])){
            $sql = "INSERT INTO $this->table_name (`manufacturer_id`, `model_name`, `quantity`) VALUES ('".$_POST['manufacturer_name']."', '".$_POST['model_name']."', '5' )";
           
            if ($this->db_conn->query($sql) === TRUE) {
              return true;
            } 
       }
       }
    public function getInventory(){
        $sql = "SELECT * FROM $this->table_name";
        $result = $this->db_conn->query($sql);
      return $result;

    }
    public function deleteModel(){
        
        $model_id = $_POST['model_id'];
        
        $sql = "Select `quantity` FROM $this->table_name WHERE `model_id` = '".$model_id."'";
      
        $result = $this->db_conn->query($sql);
         while($row = $result->fetch_assoc()){
             $count = $row['quantity'];
             
             if($count > 1){
              $new_count = $count - 1;
                $sql1 = "UPDATE $this->table_name SET `quantity` = '".$new_count."' WHERE `model_id` = '".$model_id."'";
                $this->db_conn->query($sql1);
             }
             else{
                 $sql1 = "DELETE FROM $this->table_name WHERE `model_id` = '".$model_id."'";
                $this->db_conn->query($sql1);
             }
             
             
         }
        
    }
    
}

?>