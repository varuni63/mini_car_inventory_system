 <footer>
    <div class="container">
        <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="footer-text">
             <p>mini car inventory system</p>
             </div>
        </div>
        </div>
    </div>
    </footer>
</body>
    <script src="assets/js/jquery-1.10.2.js"></script>
    <script src="assets/js/bootstrap.js"></script>
    <script src="assets/js/npm.js"></script>
    <script src="https://cdn.datatables.net/1.10.18/js/jquery.dataTables.min.js"></script>
    <script>
    $(document).ready(function() {
    $('#data_table').DataTable();
    } );
    </script>

<script>
$(document).ready(function(){
    $("#submit").click(function(){
       var name = $("#manufacturer_name").val();
       if (name == "") {
            alert("Please enter manufacturer name.");
            return false;
        } 
        else{
                        
             var form_data = {
         manufacturer_name: $('#manufacturer_name').val()
             }
           $.ajax({
             url: 'add_manufacturer_to_db.php',
             type: 'POST',
             data: form_data,
             success: function(data) {
                  alert('Success');
               window.location.href = 'http://localhost/mini_car_inventory';  
                
             }
             

            });
        }
    });
      
    
     $("#submit1").click(function(){
         var manufacturer_name = $("#manufacturer_name").val();
             if(manufacturer_name == 0){
               alert("Please select manufcturer.");
                return false;
           }
         $("#manufacturer_name").change(function(){
             var manufacturer_name = $("#manufacturer_name").val();
            
             if(manufacturer_name == 0){
               alert("Please select manufcturer.");
                return false;
           }
         });
         

       var model_name = $("#model_name").val();
       if (model_name == "") {
            alert("Please select model name.");
            return false;
        } 
        
        else{
                        
             var form_data = {
                manufacturer_name: $('#manufacturer_name').val(),
                model_name: $('#model_name').val()
             }
            
           $.ajax({
             url: 'add_model_to_db.php',
             type: 'POST',
             data: form_data,
             success: function(data) {
                  alert('Success');
               window.location.href = 'http://localhost/mini_car_inventory';  
                
             }
             

            });
        }
    });
    
    $(".delete_model").click(function(){
       
       var form_data = {
                model_id: $(this).attr('data-id')
             }
//       alert(JSON.stringify(form_data));
           $.ajax({
             url: 'sold.php',
             type: 'POST',
             data: form_data,
             success: function(data) {
                 alert('Success');
                 window.location.href = 'http://localhost/mini_car_inventory';  
                
             }
             

            });
        
    });
    
    
});
  
      
</script>
</html>