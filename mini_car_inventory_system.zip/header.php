<?php include_once 'classes/database.php'; ?>
<!DOCTYPE HTML>
<html>
<head>
<title><?php echo $page_title; ?></title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="assets/css/bootstrap.css" type="text/css" rel="stylesheet">
    <link href="assets/css/style.css" type="text/css" rel="stylesheet">
    <link href="https://cdn.datatables.net/1.10.18/css/jquery.dataTables.min.css" type="text/css" rel="stylesheet">
</head>
<body>
    <header>
     <div class="container">
        <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
            <div class="title">
             <h3>mini car inventory system</h3>
             </div>
        </div>
        </div>
    </div>
    </header>
   